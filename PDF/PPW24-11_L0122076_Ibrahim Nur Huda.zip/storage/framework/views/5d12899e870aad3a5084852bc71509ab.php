

<?php $__env->startSection('title', 'Form'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <form method="post" action="<?php echo e(route('form.submit')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="carName" class="form-label">Car Name</label>
                <input type="text" class="form-control" id="carName" name="carName" required>
            </div>
            <div class="mb-3">
                <label for="brandName" class="form-label">Brand Name</label>
                <input type="text" class="form-control" id="brandName" name="brandName" required>
            </div>
            <div class="mb-3">
                <label for="carPrice" class="form-label">Price</label>
                <input type="number" class="form-control" id="carPrice" name="carPrice" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPW11\resources\views/form.blade.php ENDPATH**/ ?>