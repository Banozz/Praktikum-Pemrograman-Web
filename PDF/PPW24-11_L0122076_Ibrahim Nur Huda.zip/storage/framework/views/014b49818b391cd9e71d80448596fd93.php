

<?php $__env->startSection('title', 'Table'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container p-5">
        <div class="card p-3 shadow">
            <?php if(count($cars) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Brand</th>
                            <th scope="col">Name</th>
                            <th scope="col">Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($car->brandName); ?></td>
                                <td><?php echo e($car->carName); ?></td>
                                <td><?php echo e($car->carPrice); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Brand</th>
                            <th scope="col">Name</th>
                            <th scope="col">Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Car Name Here</td>
                            <td>Car Brand Here</td>
                            <td>Car Price Here</td>
                        </tr>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPW11\resources\views/home.blade.php ENDPATH**/ ?>