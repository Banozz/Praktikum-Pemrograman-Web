

<?php $__env->startSection('title', 'Table'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Submitted Data</h1>
        <?php if(count($data) > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Car Name</th>
                        <th scope="col">Brand Name</th>
                        <th scope="col">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['carName']); ?></td>
                            <td><?php echo e($item['brandName']); ?></td>
                            <td><?php echo e($item['carPrice']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No data available.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PPW11\resources\views/table.blade.php ENDPATH**/ ?>